<?php

class WPBakeryShortCode_VC_Separator extends WPBakeryShortCode {

	public function outputTitle( $title ) {
		return '';
	}
}